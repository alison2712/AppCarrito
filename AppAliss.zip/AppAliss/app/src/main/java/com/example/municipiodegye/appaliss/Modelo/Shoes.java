package com.example.municipiodegye.appaliss.Modelo;

import java.io.Serializable;

public class Shoes implements Serializable {
    int id;
    String nombreArticulo;
    String marca;
    double precio;
    String url_image;
    String url_image_poster;
    String descripcion;
    String HayPromocion;
    int porctajeDescuesto;
    String TotalConDescuesnto;

    public Shoes(int id, String nombreArticulo, String marca, double precio, String url_image, String url_image_poster, String descripcion, String hayPromocion, int porctajeDescuesto, String totalConDescuesnto) {
        this.id = id;
        this.nombreArticulo = nombreArticulo;
        this.marca = marca;
        this.precio = precio;
        this.url_image = url_image;
        this.url_image_poster = url_image_poster;
        this.descripcion = descripcion;
        HayPromocion = hayPromocion;
        this.porctajeDescuesto = porctajeDescuesto;
        TotalConDescuesnto = totalConDescuesnto;
    }

    //gett
    public int getId() {
        return id;
    }

    public String getNombreArticulo() {
        return nombreArticulo;
    }

    public String getMarca() {
        return marca;
    }

    public double getPrecio() {
        return precio;
    }

    public String getUrl_image() {
        return url_image;
    }

    public String getUrl_image_poster() {
        return url_image_poster;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getHayPromocion() {
        return HayPromocion;
    }

    public int getPorctajeDescuesto() {
        return porctajeDescuesto;
    }

    public String getTotalConDescuesnto() {
        return TotalConDescuesnto;
    }

    //sett

    public void setPorctajeDescuesto(int porctajeDescuesto) {
        this.porctajeDescuesto = porctajeDescuesto;
    }

    public void setTotalConDescuesnto(String totalConDescuesnto) {
        TotalConDescuesnto = totalConDescuesnto;
    }
}




